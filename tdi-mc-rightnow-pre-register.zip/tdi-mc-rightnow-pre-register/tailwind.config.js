/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    screens: {
      md: "512px",
    },

    extend: {
      colors: {
        PRIMARY_COLOR: "#FF4D6B",
        SECOND_COLOR: "#7675FE",
        THIRD_COLOR: "#F47DAA",

        SUCCESS_COLOR: "#01BF64",
        ERROR_COLOR: "#F67269",
        WARNING_COLOR: "#FD853A",
        DISABLE_COLOR: "#DBDEE5",
        // Text Color
        GRAY_COLOR: "##424553",
        WHITE_COLOR: "#ffffff",
        WHITE_GRAY_COLOR: "#D0D5DD",
      },
    },
  },
  plugins: [],
};
