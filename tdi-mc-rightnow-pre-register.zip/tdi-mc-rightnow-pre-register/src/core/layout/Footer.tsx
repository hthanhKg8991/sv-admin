import { ReactElement } from "react";
import Button from "../components/Button";
type FooterProps = {
  button: ReactElement<typeof Button>;
};
const Footer = ({ button }: FooterProps) => {
  return (
    <div className="mx-[20px] footer">
      <Button {...button} />
    </div>
  );
};
export default Footer;
