import React from "react";
import Header from "./Header";
import Footer from "./Footer";
import { VariantProps, cva } from "class-variance-authority";
import { cn } from "../utils/utils";
import LoadingPage from "../components/Loading/LoadingPage";
const MainLayoutVariants = cva("main", {
  variants: {
    variant: {
      default: "flex flex-1 h-full w-full flex-col",
    },
  },
  compoundVariants: [{ variant: "default" }],
  defaultVariants: {
    variant: "default",
  },
});

const MainLayout = ({
  header,
  footer,
  children,
  variant,
  className,
  loading,
  openLoginForm,
  setIsShowInvitedFriend,
}: any) => {
  return (
    <div className={cn(MainLayoutVariants({ variant, className }))}>
      <Header
        {...header}
        openLoginForm={openLoginForm}
        setIsShowInvitedFriend={setIsShowInvitedFriend}
      />
      <div className="flex-1 h-full w-full mt-10">{children}</div>
      {footer && <Footer button={footer} />}
      {loading && <LoadingPage />}
    </div>
  );
};
export default MainLayout;
