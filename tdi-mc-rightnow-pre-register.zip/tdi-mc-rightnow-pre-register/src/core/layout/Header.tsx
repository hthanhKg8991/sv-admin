import React, { FC, useState } from "react";
import Text from "../components/Text";
import { Languages } from "@/app/config/DummyData";
import { setLanguage, useLang } from "../i18n";
import HumanIcon from "/icons/human.svg";
import { useIntl } from "react-intl";
import { useNavigate } from "react-router-dom";

const Header = ({ openLoginForm }: any) => {
  const intl = useIntl();
  const navigate = useNavigate();
  const lang = useLang();
  const [isLang, setIsLang] = useState<string>(lang);
  const handleLang = (lang: string) => {
    setLanguage(lang);
    setIsLang(lang);
  };

  const token = localStorage.getItem("token");

  return (
    <div className="flex flex-grow justify-between items-center bg-[#191819]  py-[9px] w-full z-10 px-[16px] md:px-[28px]">
      <div
        className="text-[12px] font-bold text-[white] leading-[16px] flex gap-[2px]"
        onClick={() => {
          if (token) navigate("/mypage");
          else openLoginForm();
        }}
      >
        <img src={HumanIcon} />
        {intl.formatMessage({ id: "CHECK-REF" })}
      </div>
      <div className="flex flex-row ">
        {Languages.map((item, index) => {
          return (
            <div
              onClick={() => handleLang(item.id)}
              key={item.name.toString()}
              className={`flex items-center text-[#D0D5DD] text-[12px] leading-[18px] ${
                item.id === isLang ? "text-[#fff] font-bold" : ""
              } `}
            >
              {item.name}

              {index < 2 && (
                <div className="bg-[#98A2B3] h-[12px] w-[1px] mx-[8px]"></div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
export default Header;
