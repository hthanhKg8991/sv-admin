function SearchBigGray() {
  return (
    <section className="searchbar_wrap">
      <div className="searchbar_container">
        <input
          //   ref={searchInput}
          //   type="text"
          //   placeholder="궁금한 피드의 키워드를 입력해보세요."
          //   onChange={(e) => setSearch(e.target.value)}
          //   onKeyDown={(event) => {
          //     if (event.key === "Enter") {
          //       searchAction();
          //       searchInput?.current?.blur();
          //     }
          //   }}
          // onFocus={handleFocus}
          autoFocus
        />
        {/*    <button>
          <img src={search_icon} alt="검색" />
        </button> */}
      </div>
    </section>
  );
}

export default SearchBigGray;
