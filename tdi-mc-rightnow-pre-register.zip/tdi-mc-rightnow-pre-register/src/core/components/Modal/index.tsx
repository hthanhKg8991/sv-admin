import { useEffect } from "react";
import CloseX from "/icons/closeX.svg";

function Modal({
  header,
  content,
  footer,
  modalBox,
  closable = true,
  onClose,
}: any) {
  useEffect(() => {
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = "unset";
    };
  }, []);

  return (
    <div className="modal_wrap">
      {modalBox ? (
        modalBox
      ) : (
        <div className="absolute w-full bottom-0 rounded-tl-2xl rounded-tr-2xl">
          <div className="modal_box">
            {closable && (
              <img
                id="closeX"
                src={CloseX}
                style={{ float: "right" }}
                onClick={() => onClose()}
              />
            )}
            {header && <div className="modal_box_header">{header}</div>}

            {content && <div className="modal_box_content">{content}</div>}
          </div>
          {footer && <div className="modal_box_footer">{footer}</div>}
        </div>
      )}
    </div>
  );
}

export default Modal;
