import { cn } from "@/core/utils/utils";
import { VariantProps, cva } from "class-variance-authority";
import { ReactNode, useEffect, useState } from "react";

const BottomSheetVariants = cva("bottomSheet", {
  variants: {
    variant: {
      default: "w-full h-full fixed left-0 z-20",
    },
  },
  compoundVariants: [{ variant: "default" }],
  defaultVariants: {
    variant: "default",
  },
});

interface BottomSheetProps extends VariantProps<typeof BottomSheetVariants> {
  open?: boolean;
  children: ReactNode;
  onDismiss?: VoidFunction;
  className?: string;
}
const BottomSheet = ({
  open,
  children,
  onDismiss,
  variant,
  className,
}: BottomSheetProps) => {
  const handleDismiss = () => {
    onDismiss && onDismiss();
  };
  return (
    open && (
      <div className={cn(BottomSheetVariants({ variant, className }))}>
        <div
          className={`z-10 w-full absolute bottom-0 bg-white rounded-tl-2xl rounded-tr-2xl animated slide-up
          } `}
        >
          {children}
        </div>
        <div
          className="h-full w-full fixed top-0 bottom-0 left-0 bg-black bg-opacity-30 animated fade-in"
          onClick={handleDismiss}
        ></div>
      </div>
    )
  );
};
export default BottomSheet;
