import { Tooltip } from "antd";
import Text from "@/core/components/Text";

function Button({
  text,
  onClick,
  style,
  logo,
  logoStyle,
  children,
  disabled,
  tolltipOpen,
  tolltipText,
  className,
}: any) {
  return (
    <button
      className={`core-button ${
        disabled ? "core-button-disbled" : ""
      } ${className}`}
      onClick={() => onClick()}
      style={style}
      disabled={disabled}
    >
      {children ? (
        <>{children}</>
      ) : (
        <>
          <img className="img" src={logo} style={logoStyle} />
          {text}
          {/* <Text variant={"lg"} className="font-bold">{text}</Text> */}
          <div className="absolute right-[0px]">
            <Tooltip
              placement="topRight"
              title={tolltipText}
              color="#00A569"
              open={tolltipOpen}
            ></Tooltip>
          </div>
        </>
      )}
    </button>
  );
}

export default Button;
