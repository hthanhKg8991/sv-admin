import { cn } from "@/core/utils/utils";
import { VariantProps, cva } from "class-variance-authority";
import { HtmlHTMLAttributes, ReactElement, ReactNode, forwardRef } from "react";

const MCHeadingVariants = cva("", {
  variants: {
    variant: {
      default:
        "whitespace-pre-line text-[24px] text-WHITE_COLOR font-semibold leading-8", // size 24
      lg: "whitespace-pre-line text-lg text-WHITE_COLOR font-normal leading-[26px]", //size 18
      md: "whitespace-pre-line text-medium text-base leading-6 text-WHITE_COLOR not-italic", // size 16
      mediumSuccess:
        "whitespace-pre-line text-medium text-base leading-6 text-[#00A569] not-italic", // size 16
      sm: "whitespace-pre-line text-sm leading-6 text-WHITE_COLOR not-italic", //size 14
      xs: "whitespace-pre-line text-medium text-xs leading-6 text-[#858E9E] not-italic", //size 12
      xl: "whitespace-pre-line text-xl text-WHITE_COLOR font-semibold leading-8 not-italic", // size 24
    },
  },
  compoundVariants: [{ variant: "default" }],
  defaultVariants: {
    variant: "default",
  },
});

interface MCHeadingProp
  extends HtmlHTMLAttributes<HTMLHeadingElement>,
    VariantProps<typeof MCHeadingVariants> {}
const MCHeading = forwardRef<HTMLHeadingElement, MCHeadingProp>(
  ({ className, variant, children, ...props }, ref) => {
    return (
      <div
        ref={ref}
        className={cn(MCHeadingVariants({ variant, className }))}
        {...props}
      >
        {children}
      </div>
    );
  }
);
MCHeading.displayName = "MCHeading";
export default MCHeading;
