import axios, { AxiosResponse } from "axios";
import { notification } from "antd";
import { useLang } from "../i18n";
type NotificationType = "success" | "info" | "warning" | "error";

const API_URL = import.meta.env.VITE_API_ENDPOINT;
const REFRESH_TOKEN_URL = `${API_URL}/admin/auth/refresh`;

const AUTH_LOCAL_STORAGE_KEY = "authentication";
const getAuth = (): any | undefined => {
  if (!localStorage) {
    return;
  }

  const lsValue: string | null = localStorage.getItem(AUTH_LOCAL_STORAGE_KEY);
  if (!lsValue) {
    return;
  }

  try {
    const auth: any = JSON.parse(lsValue) as any;
    if (auth) {
      // You can easily check auth_token expiration also
      return auth;
    }
  } catch (error) {
    console.error("AUTH LOCAL STORAGE PARSE ERROR", error);
  }
};

const setAuth = (auth: any) => {
  if (!localStorage) {
    return;
  }

  try {
    const lsValue = JSON.stringify(auth);
    localStorage.setItem(AUTH_LOCAL_STORAGE_KEY, lsValue);
  } catch (error) {
    console.error("AUTH LOCAL STORAGE SAVE ERROR", error);
  }
};

const removeAuth = () => {
  if (!localStorage) {
    return;
  }

  try {
    localStorage.removeItem(AUTH_LOCAL_STORAGE_KEY);
  } catch (error) {
    console.error("AUTH LOCAL STORAGE REMOVE ERROR", error);
  }
};

const refreshToken = () => {
  const refresh_token = getAuth()?.refresh_token;
  return axios
    .post(`${REFRESH_TOKEN_URL}`, { refresh_token })
    .then((response: any) => response.data)
    .then((response: any) => response.data);
};

export function setupAxios(axios: any) {
  const i18nConfigString = localStorage.getItem("i18nConfig");

  const i18nConfig =
    i18nConfigString && JSON.parse(localStorage.getItem("i18nConfig") || "");
  const selectedLang = i18nConfig?.selectedLang == "vi" ? "vi" : "en";

  axios.defaults.headers.Accept = "application/json";
  axios.interceptors.request.use(
    (config: {
      headers: { Authorization: string; "Accept-Language": string };
    }) => {
      if (config.headers.Authorization) return config;

      const auth = getAuth();
      const token = auth?.access_token;
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
        config.headers[`Accept-Language`] = selectedLang;
      }
      return config;
    },
    (err: any) => Promise.reject(err)
  );

  axios.interceptors.response.use(
    (response: any) => {
      return response;
    },
    async function (error: any) {
      if (error?.response?.data?.code == 422) return error.response;
      if (
        error?.response?.data?.message &&
        error?.response?.data?.code != 401
      ) {
        notification.destroy();
        notification.error({
          message: `${error?.response?.data?.message || "Error"}`,
          duration: 3,
          //style: { backgroundColor: "#f1416c", color: "white" },
        });
      }

      const originalRequest = error.config;

      if (originalRequest._retry || originalRequest.url.includes("refresh")) {
        removeAuth();
        // window.location.href = "/login";
      }
      // if (error?.response?.status === 403 && !originalRequest._retry) {
      //   const res = await refreshToken();

      //   const new_access_token = res?.access_token?.token;
      //   originalRequest._retry = true;

      //   axios.defaults.headers.common["Authorization"] =
      //     "Bearer " + new_access_token;
      //   originalRequest.headers["Authorization"] = "Bearer " + new_access_token;

      //   const stringAuth = localStorage.getItem(AUTH_LOCAL_STORAGE_KEY);
      //   if (stringAuth?.length) {
      //     const jsonAuth = JSON.parse(stringAuth);

      //     jsonAuth.meta.access_token.token = new_access_token;

      //     setAuth(jsonAuth);
      //   }

      //   return axios(originalRequest);
      // }

      return error.response;
      //return Promise.reject(error);
    }
  );
}

export { getAuth, setAuth, removeAuth, AUTH_LOCAL_STORAGE_KEY };
