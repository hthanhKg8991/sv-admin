import { ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function fortmatDistance(distance: any) {
  if (distance < 1) return Math.round(distance * 1000) + " m";
  else return Math.round(distance) + " km";
}

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function isNull(variable: any) {
  return null === variable || undefined === variable || "" === variable;
}

export function isEmptyArray(variable: any) {
  return !(
    !isNull(variable) &&
    variable instanceof Array &&
    variable.length > 0
  );
}

export const removeSpace = (value: string) => {
  let patten = /\s+/g;
  return value?.trim()?.replace(patten, " ");
};
export const removeSpecialCharacter = (value: any) => {
  let patten = /[^a-zA-Z0-9 ]/g;
  return removeSpace(value)?.replace(patten, "");
};
export const validatePhone = (phone: any) => {
  let patterMobile = "((\\+84[1-9][0-9]{8})|(0[1-9][0-9]{8}))";
  let regex = RegExp(patterMobile);
  if (!regex.test(phone.toString())) {
    return false;
  } else {
    return true;
  }
};

export function commafy(num: any) {
  var str = num.toString().split(".");
  if (str[0].length >= 5) {
    str[0] = str[0].replace(/(\d)(?=(\d{3})+$)/g, "$1,");
  }
  if (str[1] && str[1].length >= 5) {
    str[1] = str[1].replace(/(\d{3})/g, "$1 ");
  }
  return str.join(".");
}

export function formatNumberBeforeSend(prefix: any, num: any) {
  if (!num) return;
  num = num?.toString();
  while (num?.charAt(0) === "0") {
    num = num?.substring(1);
  }
  console.log(num);
  return prefix + num;
}
export function stringInterpolateStyle(theString: string, argumentArray: any, style?:any) {
  var regex = /%s/;
  var _r = function (p: string, c: any) { return p.replace(regex,  `<span class='${style}'>${c}</span>`); }
  return argumentArray.reduce(_r, theString);
}