
export const LocalStorage = {
    get(key: any) {
        try {
            return JSON.parse(localStorage?.getItem(key) as any);
        } catch (e) {
          console.warn(e);
          return null;
        }
      },
      set(key: string, data: any): void {
        try {
            localStorage.setItem(key, JSON.stringify(data) );
        } catch (e) {
          console.warn(e);
        }
      },
      remove(key: string): void {
          localStorage.removeItem(key);
      },
}