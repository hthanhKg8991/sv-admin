import ReactDOM from "react-dom/client";
import App from "./App.tsx";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { MetacrewI18nProvider } from "./core/i18n/index.tsx";
import { I18nProvider } from "./core/i18n/i18nProvider.tsx";
import "./index.css";
import axios from "axios";
import { setupAxios } from "./core/utils/AuthHelper.ts";
import { AppRoutes } from "./app/routes/AppRoutes.tsx";

const queryClient = new QueryClient();
setupAxios(axios);

ReactDOM.createRoot(document.getElementById("root") as HTMLElement).render(
  <>
    <QueryClientProvider client={queryClient}>
      <MetacrewI18nProvider>
        <I18nProvider>
          <AppRoutes />
        </I18nProvider>
      </MetacrewI18nProvider>
    </QueryClientProvider>
  </>
);
