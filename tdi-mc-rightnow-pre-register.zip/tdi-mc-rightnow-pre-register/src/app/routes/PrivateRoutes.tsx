import { Navigate, Route, Routes } from "react-router-dom";
import HomePage from "../modules/home";
import InvitedFriends from "../modules/InvitedFriends";

const PrivateRoutes = () => {
  return (
    <Routes>
      <Route path="mypage/*" element={<InvitedFriends />} />

      <Route path="*" element={<HomePage />} />
    </Routes>
  );
};

export { PrivateRoutes };
