import { FC } from "react";
import { Routes, Route, BrowserRouter, Navigate } from "react-router-dom";
import { PrivateRoutes } from "./PrivateRoutes";
// import { ErrorsPage } from "../_modules/errors/ErrorsPage";
// import { Logout, AuthPage, useAuth } from "app/_modules/auth";
import App from "../../App";

const AppRoutes: FC = () => {
  // const { currentUser } = useAuth();

  return (
    <BrowserRouter>
      <Routes>
        <Route element={<App />}>
          <Route path="/*" element={<PrivateRoutes />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
};

export { AppRoutes };
