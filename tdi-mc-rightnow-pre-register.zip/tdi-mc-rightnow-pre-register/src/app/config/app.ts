const API_ENDPOINT = import.meta.env.VITE_API_ENDPOINT;
let ConfigDefault = {
    dev:{
        BASE_URL: API_ENDPOINT,
    },
    sandbox:{
        BASE_URL: "API_ENDPOINT_SANDBOX",
    },
    product:{
        BASE_URL: "API_ENDPOINT_PRODUCT",
    },
}
export default ConfigDefault.dev;