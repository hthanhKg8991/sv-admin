export const NavLef = [
  { id: 1, name: "Home", slug: "" },
  { id: 2, name: "About", slug: "about" },
  { id: 3, name: "Products", slug: "Products" },
];
export const navRight = [
  { id: 1, name: "Login", slug: "" },
  { id: 1, name: "Register", slug: "Products" },
];
export const Languages = [
  { id: "vi", name: "Tiếng Việt", slug: "" },
  { id: "en", name: "English", slug: "" },
  { id: "ko", name: "한국어", slug: "" },
];
