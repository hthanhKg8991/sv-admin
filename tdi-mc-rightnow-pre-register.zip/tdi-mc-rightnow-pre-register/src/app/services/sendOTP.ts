import GeneralAPI from "./generalAPI";

class SendOTPServices extends GeneralAPI {
    register(params: any){
        let url="customer-events/send-otp";
        console.log('params>>>0', params);
        return this.POST(url, params);
    }
    verify(params: any){
        let url="customer-events/verify";
        console.log('params>>>0', params);
        return this.POST(url, params);
    }
    finish(params: any){
        let url="customer-events/finish";
        console.log('params>>>0', params);
        return this.POST(url, params);
    }
}
const SendOTPServiceInstance = new SendOTPServices();
export default SendOTPServiceInstance;