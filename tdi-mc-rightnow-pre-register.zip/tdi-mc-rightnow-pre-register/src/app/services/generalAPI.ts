import axios from "axios";
import ConfigDefault from "@/app/config/app";
const evn = ConfigDefault.BASE_URL;
export default class GeneralAPI {
    async GET(path:string, params?:any, header?: any){
        return axios.get(`${evn}/${path}`, params);
    }
    async POST(path:string, params:any, header?: any){
        return axios.post(`${evn}/${path}`, params);
    }
}