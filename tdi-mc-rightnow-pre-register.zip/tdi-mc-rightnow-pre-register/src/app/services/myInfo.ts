import axios from "axios";
const API_ENDPOINT = import.meta.env.VITE_API_ENDPOINT;

export function loginSocial(phone: any, password: any) {
  const body = {
    phone,
    password,
    fcmToken: "123",
  };
  return axios.post(`${API_ENDPOINT}/auth/login`, body);
}

export function getReferalUsers(token: any) {
  return axios.get(
    `${API_ENDPOINT}/customer-events/referral-users?page=1&limit=2000`,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
}

export function getMyInfo(token: any) {
  return axios.get(`${API_ENDPOINT}/customer-events/info`, {
    headers: { Authorization: `Bearer ${token}` },
  });
}

export function getAllCountries() {
  return axios.get(`${API_ENDPOINT}/sample`, {
    params: {
      name: "CountryCode",
    },
  });
}

export function linkClickSave(agencyCode: any, referralCode: any) {
  const body = {
    agencyCode: agencyCode,
    referralCode: referralCode,
  };
  return axios.post(`${API_ENDPOINT}/referral-link-clicked`, body);
}
