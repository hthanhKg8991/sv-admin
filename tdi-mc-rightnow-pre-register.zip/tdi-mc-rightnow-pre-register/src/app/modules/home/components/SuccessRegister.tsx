import { particlesConfig } from "@/app/config/particles";
import { loadConfettiPreset } from "tsparticles-preset-confetti";
import FivePercentDiscount from "/images/5percent.png";
import CopyIcon from "/icons/copy.svg";
import ShareIcon from "/icons/share.svg";
import TelegramIcon from "/icons/zalo.png";
import Button from "@/core/components/Button";
import { useLang } from "@/core/i18n";
import CopyToClipboard from "react-copy-to-clipboard";
import { useIntl } from "react-intl";
import Particles from "react-particles";
import ModalComponent from "@/core/components/Modal";
import Text from "@/core/components/Text";
import { removeSpecialCharacter } from "@/core/utils/utils";
import { useEffect, useState } from "react";
import CopySuccess from "./SuccessModal";
import RedExlamation from "/icons/red_exclamation.svg";
import BlueExclamtion from "/icons/blue_exclamation.svg";

export default function SuccessModal({
  surname,
  phone,
  mylink,
  onClose,
  setErrorMessagePassword,
}: any) {
  const intl = useIntl();
  const lang = useLang();
  const [isShowCopySuccess, setIsShowCopySuccess] = useState(false);
  const [isShowConfetti, setIsShowConfetti] = useState(true);

  const customInit = async (engine: any) => {
    // this adds the preset to tsParticles, you can safely use the
    await loadConfettiPreset(engine);
  };

  useEffect(() => {
    let timer = setTimeout(() => setIsShowConfetti(false), 10000);
    return () => {
      clearTimeout(timer);
    };
  }, []);

  const renderInvitedText = () => {
    let imgCoupon = null;
    switch (lang) {
      case "en":
        imgCoupon = (
          <p>
            Invite your friends to earn additional{" "}
            <span className="text-[#F47DAA]">5%</span> commission
          </p>
        );
        break;
      case "vi":
        imgCoupon = (
          <p>
            Giới thiệu bạn bè tham gia để hưởng thêm{" "}
            <span className="text-[#F47DAA]">5%</span> chiết khấu
          </p>
        );
        break;

      case "ko":
        imgCoupon = (
          <p className=" whitespace-pre-line">
            {`친구에게 추천하면\n 친구 수익금의 `}
            <span className="text-[#F47DAA] text-2xl font-bold">5%</span>{" "}
            추가지급!
          </p>
        );
        break;
      default:
        break;
    }
    return imgCoupon;
  };

  return (
    <div className="register-success-modal">
      <ModalComponent
        onClose={() => onClose()}
        content={
          <div
            className={`flex flex-col mt-5 max-h-[88dvh] overflow-auto response-modal w-full`}
          >
            <div className="text-center rounded-[16px] bg-[#F2F4F7] p-[16px]">
              <Text className="text-black text-base font-bold mb-[16px] text-[16px] leading-[24px]">
                {intl.formatMessage({
                  id: "YOUR_PRE_REGISTRATION_IS_COMPLETED",
                })}
              </Text>

              <div className="text-[#672EFE] text-[16px] leading-[24px] font-medium text-base">
                {intl.formatMessage({ id: "NAME" })}: {surname || "-"}
              </div>
              <div className="text-[#672EFE] text-[16px] leading-[24px] font-medium">
                {intl.formatMessage({ id: "NUMBER_PHONE" })}: {phone || "-"}
              </div>

              <Text className="text-black font-normal mt-[16px] text-[14px] leading-[22px]">
                {intl.formatMessage({
                  id: "YOUR_PRE_REGISTRATION_IS_COMPLETED_DESCRIBE",
                })}
              </Text>
            </div>

            <div className="">
              <div className="text-[#4652BE] text-center font-bold text-[20px] leading-[26px] mt-[36px] mb-[12px]">
                {renderInvitedText()}
              </div>

              <div className="text-[#4652BE] text-center font-medium text-[14px] leading-[22px] mb-[12px]">
                {intl.formatMessage({
                  id: "INTRO-DETAILS",
                })}
              </div>
              <div className="flex justify-center">
                <img
                  src={FivePercentDiscount}
                  className="mb-[12px] h-[116px]"
                />
              </div>

              <div className="text-[#4652BE] font-medium text-[14px] leading-[22px] mb-[8px]">
                {intl.formatMessage({
                  id: "MY-LINK",
                })}
              </div>

              <div className="text-[#672EFE] text-[14px] leading-[22px] rounded-[8px] bg-[#EAECF0] px-[16px] py-[12px]  mb-[8px]">
                {mylink}{" "}
              </div>

              <div className="flex">
                <img src={RedExlamation} className="w-[18px] h-[18px]" />
                <div className="text-[#F47DAA] text-[12px] leading-[18px]">
                  {intl.formatMessage({
                    id: "GET-MY-LINK",
                  })}
                </div>
              </div>
            </div>

            {/*  footer */}
            <div className="text-center">
              <div className="my-[24px]">
                <div className="flex mb-[16px] gap-[8px]">
                  <CopyToClipboard
                    text={mylink || "https://reservation.rightnow.vn"}
                    onCopy={() => setIsShowCopySuccess(true)}
                  >
                    <Button className="!text-[#fff] !text-[16px] !font-medium !bg-[#672EFE] !rounded-[24px] !py-[12px] !px-[16px] !gap-[4px]">
                      {intl.formatMessage({
                        id: "COPY-REF-LINK",
                      })}
                      <img src={CopyIcon} />
                    </Button>
                  </CopyToClipboard>

                  <Button
                    className="!text-[#ffff] !text-[16px] !font-medium !bg-[#F47DAA] !rounded-[24px]  !py-[12px] !px-[16px] !gap-[4px]"
                    onClick={() => {
                      const shareData = {
                        // title: "RIGHTNOW/HẸN HÒ BẠN MỚI MANG ĐẾN THU NHẬP KHỦNG",
                        // text: "Nhận thu nhập cao hơn người khác chỉ bằng cách đăng kí thành viên trước khi ra mắt app chính thức!! Hãy tham gia Right Now ngay nhé",
                        url: mylink,
                      };

                      if (navigator?.share && navigator?.canShare(shareData)) {
                        navigator.share(shareData);
                      } else {
                        setErrorMessagePassword(
                          "Device do not support this function"
                        );
                      }
                    }}
                  >
                    {intl.formatMessage({
                      id: "SHARE",
                    })}
                    <img src={ShareIcon} />
                  </Button>
                </div>

                <a href="https://zalo.me/g/markqz677" target="_blank">
                  <Button
                    className="!text-[#ffff] !text-[16px] !font-medium !bg-[#2B66F6] !rounded-[24px]  !py-[12px] !px-[16px] !gap-[4px] mb-[8px]"
                    onClick={() => {}}
                  >
                    {intl.formatMessage({
                      id: "JOIN_ZALO_RIGHT_NOW",
                    })}
                    <img src={TelegramIcon} className="h-[24px]" />
                  </Button>
                </a>

                <div className="flex">
                  <img src={BlueExclamtion} className="w-[18px] h-[18px]" />
                  <div className="text-[#2B66F6] text-[12px] leading-[18px] text-start">
                    {intl.formatMessage({
                      id: "ZALO-BENEFIT",
                    })}
                  </div>
                </div>
              </div>

              <div className="!text-[12px] !text-[#667085] !bg-[white] !leading-[18px] mb-[60px]">
                {intl.formatMessage({
                  id: "BENIFIT-AFTER-HAFT_YEARS",
                })}
              </div>
            </div>
          </div>
        }
      />
      {isShowConfetti && (
        <Particles
          options={particlesConfig as any}
          init={customInit}
          id="tsparticles"
        />
      )}
      {isShowCopySuccess && (
        <CopySuccess
          title={intl.formatMessage({ id: "ALERT" })}
          message={intl.formatMessage({ id: "COPY-SUCCESS" })}
          onClose={() => setIsShowCopySuccess(false)}
        />
      )}
    </div>
  );
}
