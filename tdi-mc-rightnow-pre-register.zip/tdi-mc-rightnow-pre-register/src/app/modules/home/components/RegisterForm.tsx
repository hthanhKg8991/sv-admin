import Button from "@/core/components/Button";
import iconStar from "/icons/star.png";
import ModalComponent from "@/core/components/Modal";
import { useIntl } from "react-intl";
import { useEffect, useState } from "react";
import SendOTPServiceInstance from "@/app/services/sendOTP";
import ErrorModal from "./ErrorModal";
import SuccessModal from "./SuccessRegister";
import ArrowDownIcon from "/icons/gray_arrowdown.svg";
import SearchPhoneCode from "./SearchPhoneCode";
import { formatNumberBeforeSend } from "@/core/utils/utils";
import { useLang } from "@/core/i18n";
import { saveServerError } from "@/app/constants/error";

export default function registerForm({ onClose }: any) {
  const intl = useIntl();
  const lang = useLang();
  const [chosenCountryPhone, setChosenCountryPhone] = useState("+84");
  const [isShowChosenCounty, setIsShowChosenCountry] = useState(false);
  const [errorMess, setErrMess] = useState<any>();
  const [isShowSuccessModal, setIsShowSuccessModal] = useState<any>(false);

  const [name, setName] = useState<any>();
  const [phone, setPhone] = useState<any>();
  const [verifyCode, setVerifyCode] = useState<any>();
  const [password, setPassword] = useState<any>();
  const [confirmPassword, setConfirmPassword] = useState<any>();

  const [errorOnForm, setErrorOnForm] = useState<any>(null);

  const [mylink, setMyLink] = useState<any>();
  const [isWaiting, setIsWaiting] = useState<boolean>(false);

  const query = new URLSearchParams(location.search);

  const agencyCode = query.get("agencyCode");
  const referralCode = query.get("referralCode");

  const handleGetOTP = async () => {
    setIsWaiting(true);
    if (!phone || phone?.length < 6) return;
    let params = {
      customerPhone: formatNumberBeforeSend(chosenCountryPhone, phone),
    };
    await SendOTPServiceInstance.register(params).then((response) => {
      setIsWaiting(false);

      if (response?.data?.error?.code) {
        const ErrorKey = saveServerError(response?.data?.error?.code);
        const err = intl.formatMessage({
          id: ErrorKey,
        });
        setErrMess(err);
        return;
      }
      if (response.status === 200 || response.status === 201) {
        setErrMess(intl.formatMessage({ id: "MESSAGE_SEND_OTP_SUCCESS" }));
      } else
        setErrMess(
          intl.formatMessage({
            id: "MESSAGE_SEND_OTP_FAIL",
          })
        );
    });
  };

  const handleVerifyOTP = async () => {
    let params = {
      customerPhone: formatNumberBeforeSend(chosenCountryPhone, phone),
      verifyCode: verifyCode,
    };
    await SendOTPServiceInstance.verify(params).then((response) => {
      if (response?.data?.error?.code) {
        const ErrorKey = saveServerError(response?.data?.error?.code);
        const err = intl.formatMessage({
          id: ErrorKey,
        });
        setErrMess(err);
        return;
      }

      if (response.status === 200 || response.status === 201) {
        setErrMess(
          intl.formatMessage({
            id: "MESSAGE_VERIFY_OTP_SUCCESS",
          })
        );
      } else
        setErrMess(
          intl.formatMessage({
            id: "MESSAGE_VERIFY_OTP_FAIL",
          })
        );
    });
  };

  const hasErrorBeforeSubmit = () => {
    let hasError = false;
    if (!name) {
      setErrorOnForm((preState: any) => {
        return {
          ...preState,
          name: "NAME-REQUIRED",
        };
      });
      hasError = true;
    }

    if (!phone) {
      setErrorOnForm((preState: any) => {
        return {
          ...preState,
          phone: "PHONE-REQUIRED",
        };
      });
      hasError = true;
    }

    if (!verifyCode) {
      setErrorOnForm((preState: any) => {
        return {
          ...preState,
          verifyCode: "VERIFY-CODE-REQUIRED",
        };
      });
      hasError = true;
    }

    if (!password) {
      setErrorOnForm((preState: any) => {
        return {
          ...preState,
          password: "PASSWORD-REQUIRED",
        };
      });
      hasError = true;
    }

    if (!confirmPassword) {
      setErrorOnForm((preState: any) => {
        return {
          ...preState,
          confirmPassword: "CONFIRM-PASSWORD-REQUIRED",
        };
      });
      hasError = true;
    }

    return hasError;
  };

  const handleSubmit = async () => {
    if (hasErrorBeforeSubmit() || !isFormValid()) return;
    let params = {
      customerPhone: formatNumberBeforeSend(chosenCountryPhone, phone),
      password: password,
      customerName: name,
      verifyCode: verifyCode,
      agencyCode: agencyCode,
      referralCode: referralCode,
    };
    await SendOTPServiceInstance.finish(params).then((response) => {
      if (response?.data?.error?.code) {
        const ErrorKey = saveServerError(response?.data?.error?.code);
        const err = intl.formatMessage({
          id: ErrorKey,
        });
        setErrMess(err);
        return;
      }
      if (response.status === 200 || response.status === 201) {
        setIsShowSuccessModal(true);
        setMyLink(response?.data?.shortLink);
      } else {
        setErrMess(
          intl.formatMessage({
            id: "REGISTER-FAILED",
          })
        );
      }
    });
  };

  const GetOTPButton = () => {
    return (
      <button
        disabled={isWaiting || phone?.length <= 5}
        className={`${
          !isWaiting && phone?.length >= 5 ? "bg-[#672EFE]" : "bg-[#667085]"
        } w-1/4 rounded-full py-3 text-[#fff] text-[14px]`}
        onClick={() => handleGetOTP()}
      >
        {intl.formatMessage({ id: "SEND" })}
      </button>
    );
  };

  const CheckOTPButton = () => {
    return (
      <button
        disabled={verifyCode?.length !== 6}
        className={`${
          verifyCode?.length !== 6 ? "bg-[#667085]" : "bg-[#672EFE]"
        } w-1/4 rounded-full  py-3 text-[#fff] text-[14px]`}
        onClick={() => handleVerifyOTP()}
      >
        {intl.formatMessage({ id: "CONFIRM" })}
      </button>
    );
  };

  const isFormValid = () => {
    return (
      name &&
      phone &&
      verifyCode &&
      password &&
      confirmPassword &&
      !errorOnForm?.name &&
      !errorOnForm?.phone &&
      !errorOnForm?.verifyCode &&
      !errorOnForm?.password &&
      !errorOnForm?.confirmPassword
    );
  };

  useEffect(() => {
    if (name)
      setErrorOnForm((preState: any) => {
        return { ...preState, name: null };
      });

    if (phone)
      setErrorOnForm((preState: any) => {
        return { ...preState, phone: null };
      });

    if (verifyCode)
      setErrorOnForm((preState: any) => {
        return { ...preState, verifyCode: null };
      });

    if (password)
      setErrorOnForm((preState: any) => {
        return { ...preState, password: null };
      });

    if (confirmPassword)
      setErrorOnForm((preState: any) => {
        return { ...preState, confirmPassword: null };
      });

    //verify phone must enough 6 word
    if (phone?.length < 6) {
      setErrorOnForm((preState: any) => {
        return { ...preState, phone: "SIX-DIGIT-REQUIRED" };
      });
    } else if (phone?.length >= 6) {
      setErrorOnForm((preState: any) => {
        return { ...preState, phone: null };
      });
    }

    //verify code must enough 6 word
    if (verifyCode?.length < 6) {
      setErrorOnForm((preState: any) => {
        return { ...preState, verifyCode: "SIX-DIGIT-REQUIRED" };
      });
    } else if (verifyCode?.length >= 6) {
      setErrorOnForm((preState: any) => {
        return { ...preState, verifyCode: null };
      });
    }

    //verify code must enough 6 word
    if (password?.length < 6) {
      setErrorOnForm((preState: any) => {
        return { ...preState, password: "SIX-DIGIT-REQUIRED" };
      });
    } else if (password?.length >= 6) {
      setErrorOnForm((preState: any) => {
        return { ...preState, password: null };
      });
    }

    //verify code must enough 6 word
    if (confirmPassword?.length < 6) {
      setErrorOnForm((preState: any) => {
        return { ...preState, vericonfirmPasswordfyCode: "SIX-DIGIT-REQUIRED" };
      });
    } else if (verifyCode?.length >= 6) {
      setErrorOnForm((preState: any) => {
        return { ...preState, confirmPassword: null };
      });
    }

    if (password && confirmPassword && confirmPassword != password) {
      setErrorOnForm((preState: any) => {
        return { ...preState, confirmPassword: "PASSWORD-NOT-MATCH" };
      });
    } else if (confirmPassword == password) {
      setErrorOnForm((preState: any) => {
        return { ...preState, confirmPassword: null };
      });
    }
  }, [name, phone, verifyCode, password, confirmPassword]);

  if (isShowSuccessModal)
    return (
      <SuccessModal
        surname={name}
        phone={formatNumberBeforeSend(chosenCountryPhone, phone)}
        mylink={mylink}
        onClose={() => {
          setIsShowSuccessModal(false);
          onClose();
        }}
      />
    );

  if (isShowChosenCounty)
    return (
      <SearchPhoneCode
        onClose={() => setIsShowChosenCountry(false)}
        setChosenCountryPhone={setChosenCountryPhone}
      />
    );

  return (
    <div className="login-form">
      <ModalComponent
        onClose={onClose}
        content={
          <div
            className={`flex flex-col max-h-[82dvh] overflow-auto response-modal w-full`}
          >
            <div className="flex flex-col gap-3 mb-9">
              <div className="text-center text-[#4652BE] font-bold  flex flex-row items-center justify-center gap-[4px]">
                <img src={iconStar} alt="icon star" width={"20px"} />
                <div
                  className={`${
                    lang === "ko" ? "text-2xl" : "text-xl"
                  } font-bold not-italic text-[#4652BE]`}
                >
                  {intl.formatMessage({ id: "REGISTRATION_GUIDE" })}
                </div>
                <img src={iconStar} alt="icon star" width={"20px"} />
              </div>
              <div className="text-center text-base text-[#4652BE] font-medium whitespace-pre-line">
                {intl.formatMessage({ id: "REGISTRATION_GUIDE_SEND_YOU_APP" })}
              </div>
              <div className="text-center text-sm font-normal text-[#E07B97]">
                {intl.formatMessage({ id: "REGISTRATION_GUIDE_DESCRIBE" })}
              </div>
            </div>
            <form
              onSubmit={(e) => e.preventDefault()}
              className="flex flex-col gap-[20px] w-full mb-[96px]"
            >
              {/* Start name input */}
              <div className="flex flex-col  gap-[8px]">
                <label className="text-[#4652BE] font-medium text-[14px] leading-[18px]">
                  {intl.formatMessage({ id: "FULL_NAME" })}
                </label>

                <div className="w-full rounded-full flex flex-row gap-2">
                  <input
                    className={`bg-[#EAECF0] rounded-full w-full px-4 py-3`}
                    placeholder={intl.formatMessage({
                      id: "FULL_NAME_PLACEHOLDER",
                    })}
                    onChange={(e: any) => {
                      if (e.target.value.length >= 50) return;
                      setName(e?.target?.value);
                    }}
                    value={name}
                  />
                </div>

                {errorOnForm?.name && (
                  <div className="font-normal text-[#E07B97] text-[12px]  leading-[18px]">
                    {intl.formatMessage({ id: errorOnForm?.name })}
                  </div>
                )}
              </div>
              {/* End name input */}

              {/* start phone number input */}
              <div className="flex flex-col  gap-[8px]">
                <label className="text-[#4652BE] font-medium text-[14px] leading-[18px]">
                  {intl.formatMessage({ id: "PHONE_NUMBER" })}
                </label>

                <div className="w-full rounded-full flex flex-row gap-2">
                  <div className="flex w-4/5 bg-[#EAECF0] rounded-full">
                    <div
                      className="flex items-center text-[14px] ml-[16px] w-[50px]"
                      onClick={() => setIsShowChosenCountry(true)}
                    >
                      {chosenCountryPhone} <img src={ArrowDownIcon} />
                    </div>
                    <input
                      className={`bg-[#EAECF0] rounded-full w-4/5  px-4 py-3`}
                      placeholder={intl.formatMessage({
                        id: "PHONE_NUMBER_PLACEHOLDER",
                      })}
                      onChange={(e: any) => {
                        if (e.target.value.length >= 15) return;
                        setPhone(e.target.value);
                      }}
                      value={phone}
                      type="number"
                    />
                  </div>
                  <GetOTPButton />
                </div>

                {errorOnForm?.phone && (
                  <div className="font-normal text-[#E07B97] text-[12px]  leading-[18px]">
                    {intl.formatMessage({ id: errorOnForm?.phone })}
                  </div>
                )}
              </div>
              {/* end phone number input */}

              {/* start verify code input */}
              <div className="flex flex-col  gap-[8px]">
                <label className="text-[#4652BE] font-medium text-[14px] leading-[18px]">
                  {intl.formatMessage({ id: "CONFIRMATION_CODE" })}
                </label>

                <div className="w-full rounded-full flex flex-row gap-2">
                  <div className="flex w-4/5 bg-[#EAECF0] rounded-full">
                    <input
                      className={`bg-[#EAECF0] rounded-full w-4/5  px-4 py-3`}
                      placeholder={intl.formatMessage({
                        id: "CONFIRMATION_CODE_PLACEHOLDER",
                      })}
                      onChange={(e: any) => {
                        if (e?.target?.value?.length > 6) return;
                        setVerifyCode(e?.target?.value);
                      }}
                      type="number"
                      value={verifyCode}
                    />
                  </div>
                  <CheckOTPButton />
                </div>

                {errorOnForm?.verifyCode && (
                  <div className="font-normal text-[#E07B97] text-[12px]  leading-[18px]">
                    {intl.formatMessage({ id: errorOnForm?.verifyCode })}
                  </div>
                )}
              </div>
              {/* end verify code input */}

              {/* Start password input */}
              <div className="flex flex-col  gap-[8px]">
                <label className="text-[#4652BE] font-medium text-[14px] leading-[18px]">
                  {intl.formatMessage({ id: "PASSWORD" })}
                </label>

                <div className="w-full rounded-full flex flex-row gap-2">
                  <input
                    className={`bg-[#EAECF0] rounded-full w-full px-4 py-3`}
                    placeholder={intl.formatMessage({
                      id: "PASSWORD_PLACEHOLDER",
                    })}
                    type="password"
                    onChange={(e: any) => {
                      if (e.target.value.length >= 30) return;
                      setPassword(e?.target?.value);
                    }}
                    value={password}
                  />
                </div>

                {errorOnForm?.password && (
                  <div className="font-normal text-[#E07B97] text-[12px]  leading-[18px]">
                    {intl.formatMessage({ id: errorOnForm?.password })}
                  </div>
                )}
              </div>
              {/* End password input */}

              {/* Start confirm password input */}
              <div className="flex flex-col  gap-[8px]">
                <label className="text-[#4652BE] font-medium text-[14px] leading-[18px]">
                  {intl.formatMessage({ id: "CONFIRM_PASSWORD" })}
                </label>

                <div className="w-full rounded-full flex flex-row gap-2">
                  <input
                    className={`bg-[#EAECF0] rounded-full w-full px-4 py-3`}
                    placeholder={intl.formatMessage({
                      id: "CONFIRM_PASSWORD_PLACEHOLDER",
                    })}
                    type="password"
                    onChange={(e: any) => {
                      if (e.target.value.length >= 30) return;
                      setConfirmPassword(e?.target?.value);
                    }}
                    value={confirmPassword}
                  />
                </div>

                {errorOnForm?.confirmPassword && (
                  <div className="font-normal text-[#E07B97] text-[12px]  leading-[18px]">
                    {intl.formatMessage({ id: errorOnForm?.confirmPassword })}
                  </div>
                )}
              </div>
              {/* End confirm password input */}
            </form>
          </div>
        }
        footer={
          <Button
            className={`${
              !isFormValid() ? "bg-[#F47DAA]" : "bg-[#672EFE]"
            } text-[18px] font-bold not-italic !py-[17px] !px-[32px]`}
            text={intl.formatMessage({
              id: !isFormValid()
                ? "PRE_REGISTER_AND_RECEIVE_BENEFITS"
                : "COMPLETE_MEMBERSHIP_REGISTRATION",
            })}
            onClick={handleSubmit}
          />
        }
      />

      {errorMess && (
        <ErrorModal message={errorMess} onClose={() => setErrMess(null)} />
      )}
    </div>
  );
}
