import Button from "@/core/components/Button";
import ModalComponent from "@/core/components/Modal";
import { LegacyRef, useEffect, useRef, useState } from "react";
import { useIntl } from "react-intl";
import Text from "@/core/components/Text";
import { loginSocial } from "@/app/services/myInfo";
import { formatNumberBeforeSend, validatePhone } from "@/core/utils/utils";
import ErrorModal from "./ErrorModal";
import ArrowDownIcon from "/icons/gray_arrowdown.svg";
import SearchPhoneCode from "./SearchPhoneCode";
import { useNavigate } from "react-router-dom";

export default function LoginForm({ onClose, setIsShowInvitedFriend }: any) {
  const intl = useIntl();
  const navigate = useNavigate();
  const [errorMess, setErrMess] = useState<any>();
  const [chosenCountryPhone, setChosenCountryPhone] = useState("+84");
  const [isShowChosenCounty, setIsShowChosenCountry] = useState(false);
  const [errorOnForm, setErrorOnForm] = useState<any>(null);
  const [phone, setPhone] = useState<any>();
  const [password, setPassword] = useState<any>();

  const hasErrorBeforeSubmit = () => {
    let hasError = false;

    if (!phone) {
      setErrorOnForm((preState: any) => {
        return {
          ...preState,
          phone: "PHONE-REQUIRED",
        };
      });
      hasError = true;
    }

    if (!password) {
      setErrorOnForm((preState: any) => {
        return {
          ...preState,
          password: "PASSWORD-REQUIRED",
        };
      });
      hasError = true;
    }
    return hasError;
  };

  const isFormValid = () => {
    return phone && password && !errorOnForm?.phone && !errorOnForm?.password;
  };

  useEffect(() => {
    if (phone)
      setErrorOnForm((preState: any) => {
        return { ...preState, phone: null };
      });

    if (password)
      setErrorOnForm((preState: any) => {
        return { ...preState, password: null };
      });

    //verify phone must enough 6 word
    if (phone?.length < 6) {
      setErrorOnForm((preState: any) => {
        return { ...preState, phone: "SIX-DIGIT-REQUIRED" };
      });
    } else if (phone?.length >= 6) {
      setErrorOnForm((preState: any) => {
        return { ...preState, phone: null };
      });
    }

    //verify code must enough 6 word
    if (password?.length < 6) {
      setErrorOnForm((preState: any) => {
        return { ...preState, password: "SIX-DIGIT-REQUIRED" };
      });
    } else if (password?.length >= 6) {
      setErrorOnForm((preState: any) => {
        return { ...preState, password: null };
      });
    }
  }, [phone, password]);

  if (isShowChosenCounty)
    return (
      <SearchPhoneCode
        onClose={() => setIsShowChosenCountry(false)}
        setChosenCountryPhone={setChosenCountryPhone}
      />
    );

  return (
    <div className="login-form">
      <ModalComponent
        onClose={() => onClose()}
        content={
          <div
            className={`flex flex-col max-h-[70vh] overflow-auto response-modal w-full mb-[96px]`}
          >
            <div className="flex flex-col gap-3 mb-9">
              <div className="text-center text-[20px] text-[#4652BE] font-bold  flex flex-row items-center justify-center gap-2">
                <div className=" text-2xl font-bold not-italic text-[#4652BE]">
                  {intl.formatMessage({ id: "CHECK-REF" })}
                </div>
              </div>
              <div className="text-center text-[#4652BE] font-medium text-[16px]">
                {intl.formatMessage({
                  id: "CHECK-REF-INPUT",
                })}
              </div>
            </div>
            <form
              onSubmit={(e) => e.preventDefault()}
              className="flex flex-col gap-[20px] w-full"
            >
              {/* start phone number input */}
              <div className="flex flex-col  gap-[8px]">
                <label className="text-[#4652BE] font-medium text-[14px] leading-[18px]">
                  {intl.formatMessage({ id: "PHONE_NUMBER" })}
                </label>

                <div className="w-full rounded-full flex flex-row gap-2">
                  <div className="flex w-full bg-[#EAECF0] rounded-full">
                    <div
                      className="flex items-center text-[14px] ml-[16px] w-[50px]"
                      onClick={() => setIsShowChosenCountry(true)}
                    >
                      {chosenCountryPhone} <img src={ArrowDownIcon} />
                    </div>
                    <input
                      className={`bg-[#EAECF0] rounded-full w-full  px-4 py-3`}
                      placeholder={intl.formatMessage({
                        id: "PHONE_NUMBER_PLACEHOLDER",
                      })}
                      onChange={(e: any) => {
                        if (e.target.value.length >= 15) return;
                        setPhone(e.target.value);
                      }}
                      value={phone}
                      type="number"
                    />
                  </div>
                </div>

                {errorOnForm?.phone && (
                  <div className="font-normal text-[#E07B97] text-[12px]  leading-[18px]">
                    {intl.formatMessage({ id: errorOnForm?.phone })}
                  </div>
                )}
              </div>
              {/* end phone number input */}

              {/* Start password input */}
              <div className="flex flex-col gap-[8px]">
                <label className="text-[#4652BE] font-medium text-[14px] leading-[18px]">
                  {intl.formatMessage({ id: "PASSWORD" })}
                </label>

                <div className="w-full rounded-full flex flex-row gap-2">
                  <input
                    className={`bg-[#EAECF0] rounded-full w-full px-4 py-3`}
                    placeholder={intl.formatMessage({
                      id: "PASSWORD_PLACEHOLDER",
                    })}
                    type="password"
                    onChange={(e: any) => {
                      if (e.target.value.length >= 30) return;
                      setPassword(e?.target?.value);
                    }}
                    value={password}
                  />
                </div>

                {errorOnForm?.password && (
                  <div className="font-normal text-[#E07B97] text-[12px] leading-[18px]">
                    {intl.formatMessage({ id: errorOnForm?.password })}
                  </div>
                )}
              </div>
              {/* End password input */}
            </form>
          </div>
        }
        footer={
          <Button
            className={`${
              !isFormValid() ? "bg-[#F47DAA]" : "bg-[#672EFE]"
            } !py-[17px] !px-[32px]`}
            text={
              <div className="font-bold text-[18px]">
                {intl.formatMessage({ id: "SEARCH" })}
              </div>
            }
            onClick={async () => {
              if (hasErrorBeforeSubmit() || !isFormValid()) return;

              const res = await loginSocial(
                formatNumberBeforeSend(chosenCountryPhone, phone),
                password
              );

              if (res?.status == 201) {
                onClose();
                setIsShowInvitedFriend(true);
                localStorage.setItem("token", res?.data?.accessToken);
                navigate("/mypage");
              } else {
                {
                  setErrMess(intl.formatMessage({ id: "LOGIN-FAILED" }));
                }
              }
            }}
          />
        }
      />
      {errorMess && (
        <ErrorModal message={errorMess} onClose={() => setErrMess(null)} />
      )}
    </div>
  );
}
