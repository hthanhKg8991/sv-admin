import Text from "@/core/components/Text";
import { useIntl } from "react-intl";
import eventLine01 from "/images/line-event-01.png";
import eventLine02 from "/images/line-event-02.png";
import lighting from "/icons/lighting.png";
import { useLang } from "@/core/i18n";
import couponEn from "/images/coupon_en.png";
import couponVN from "/images/coupon_vn.png";
import couponKR from "/images/coupon_kr.png";
import couponVN_fold from "/images/coupon_vn_fold.png";
import couponKR_fold from "/images/coupon_kr_fold.png";
import couponEn_fold from "/images/coupon_en_fold.png";

export default function CouponSection() {
  const intl = useIntl();
  const lang = useLang();

  const renderCoupon = () => {
    let imgCoupon = null;
    switch (lang) {
      case "en":
        imgCoupon = (
          <img
            src={screen.width >= 512 ? couponEn_fold : couponEn}
            alt="right now coupon"
            width={"200px"}
            className="md:w-[280px]"
          />
        );
        break;
      case "vi":
        imgCoupon = (
          <img
            src={screen.width >= 512 ? couponVN_fold : couponVN}
            alt="right now coupon"
            width={"200px"}
            className="md:w-[280px]"
          />
        );
        break;

      case "ko":
        imgCoupon = (
          <img
            src={screen.width >= 512 ? couponKR_fold : couponKR}
            alt="right now coupon"
            width={"200px"}
            className="md:w-[280px]"
          />
        );
        break;
      default:
        break;
    }
    return imgCoupon;
  };

  return (
    <div className="flex flex-col bg-[#4652BE] text-center items-center justify-center">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-0 mt-5 mb-[96px] items-center justify-between w-full md:max-w-[512px] md:px-[28px]">
        <div className="flex flex-col items-center justify-start gap-2">
          <div className="flex flex-col items-center justify-center md:items-start md:gap-2 px-[16px]">
            <div className="flex flex-row items-center gap-6 md:items-start md:gap-0">
              <img
                src={eventLine01}
                alt="lighting left"
                width={"39px"}
                height={"71px"}
                className=" mt-6 md:hidden"
              />
              <div className="flex flex-row gap-2 text-left items-center justify-center">
                <img src={lighting} alt="lighting left" width="8px" />
                <p className="font-poppins text-[#FFCCEF] font-bold italic text-[28px]">
                  {intl.formatMessage({ id: "EVENT" })}
                </p>
                <img src={lighting} alt="lighting right" width="8px" />
              </div>
              <img
                src={eventLine02}
                alt="lighting right"
                className="md:hidden"
                width={"39px"}
                height={"71px"}
              />
            </div>
            <Text
              variant={"md"}
              className="-mt-2 md:mt-0 md:text-left text-[16px] md:w-[220px] leading-[24px]"
            >
              {intl.formatMessage({ id: "EVENT_DESCRIBE" })}
            </Text>
          </div>
        </div>
        <div className="flex justify-center w-full relative md:w-[283px] md:-left-5">
          {renderCoupon()}
          {/* <img src={coupon} alt="right now coupon" width={"200px"} /> */}
        </div>
      </div>
    </div>
  );
}
