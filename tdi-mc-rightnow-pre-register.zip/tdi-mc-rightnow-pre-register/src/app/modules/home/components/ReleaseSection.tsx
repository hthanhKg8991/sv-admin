import Text from "@/core/components/Text";
import { useIntl } from "react-intl";
import HeartFold from "/images/HeartFold.png";
import HeartPhone from "/images/HeartPhone.png";
import ArrowDown from "/icons/arrow-down.svg";
import { useLang } from "@/core/i18n";

export default function ReleaseFunction() {
  const intl = useIntl();
  const lang = useLang();

  return (
    <>
      <Text
        variant={"sm"}
        className={`${
          lang === "ko" ? "text-[18px]" : "text-[20px]"
        } leading-[22px] not-italic md:text-[20px] font-bold text-[white] mb-[-15px]`}
      >
        {intl.formatMessage({ id: "DATING_PLATFORM" })}
      </Text>
      <div className="flex mb-6 mr-[-12px] -mt-3">
        <img
          src={screen.width >= 512 ? HeartFold : HeartPhone}
          alt="background right now"
          className="w-[310px] md:w-[350px]"
        />
      </div>
      <div>
        <Text
          variant={"xs"}
          className={`text-[#fff] font-extrabold mt-1 !leading-[30px] ${
            lang == "ko"
              ? "text-[24px] md:text-[26px] "
              : "text-[20px] md:text-[24px] "
          } release-text`}
        >
          {intl.formatMessage({ id: "LAUNCHING_JANUARY" })}
        </Text>
      </div>
      <div className="my-4">
        <img src={ArrowDown} alt="arrow down" />
      </div>
    </>
  );
}
