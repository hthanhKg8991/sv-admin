import ArrowLeft from "/icons/Arrow_Left_MD.svg";
import SearchGray from "/icons/search_gray.svg";
import InputDelete from "/icons/input_delete.svg";
import { useEffect, useState } from "react";
import { useDebounce } from "@/core/utils/hooks";
import { getAllCountries } from "@/app/services/myInfo";
import Modal from "@/core/components/Modal";
import { useIntl } from "react-intl";
import { useLang } from "@/core/i18n";

function SearchHospital({ onClose, setChosenCountryPhone }: any) {
  const intl = useIntl();
  const lang = useLang();

  const [searching, setSearching] = useState<any>("");
  const [chosenLocation, setChosenLocation] = useState<any>("");

  return (
    <Modal
      onClose={onClose}
      content={
        <div
          className={`flex flex-col max-h-[80dvh] response-modal pb-5 w-full`}
        >
          <div className="footerOnly searchHospitall !justify-start">
            <div className="flex flex-col text-center items-center">
              <div className={`w-full ${lang ==='ko'?"text-[24px]": "text-[20px]"} ${lang ==='ko'?"leading-[30px]": "leading-[26px]"} text-black font-bold  not-italic`}>
                {intl.formatMessage({ id: "CHOOSE-COUNTRY" })}
              </div>

              <div className="big-search mt-[16px] w-full">
                <img src={SearchGray} className="w-[24px] h-[24px]" />
                <input
                  placeholder={intl.formatMessage({
                    id: "CHOOSE-COUNTRY_PLACEHOLDER",
                  })}
                  value={searching}
                  onChange={(e) => {
                    setSearching(e.target.value);
                  }}
                  className="bg-[#F3F4F6] placeholder:text-[#9CA3AF]"
                />
                {searching.length > 0 && (
                  <img
                    src={InputDelete}
                    onClick={() => {
                      setSearching("");
                      setChosenLocation("");
                    }}
                    className="h-[24px] w-[24px]"
                  />
                )}
              </div>
            </div>

            <div className="h-[1px] bg-[#F2F4F7] my-[20px]"></div>

            <div className="overflow-auto">
              <RelativeKeyword
                searching={searching}
                setChosenLocation={(location: any) => {
                  setChosenCountryPhone(location?.countryCodes[0]);
                  setSearching("");
                  onClose();
                }}
              />
            </div>
          </div>
        </div>
      }
    />
  );
}

function RelativeKeyword({ searching, setChosenLocation }: any) {
  const [allCountries, setAllCountries] = useState<any>([]);
  const [listSuggestion, setListSuggestion] = useState<any>([]);

  const debouncedSearchTerm = useDebounce(searching, 500);

  useEffect(() => {
    async function getData() {
      if (!debouncedSearchTerm) {
        setListSuggestion(allCountries);
        return;
      }

      const filterCountries = allCountries.filter((i: any) => {
        return i?.name
          .toLowerCase()
          .includes(debouncedSearchTerm?.toLocaleLowerCase());
      });

      setListSuggestion(filterCountries);
    }
    getData();
  }, [debouncedSearchTerm]);

  useEffect(() => {
    async function getData() {
      const res = await getAllCountries();
      //search action
      if (res?.status == 200) {
        setAllCountries(res?.data?.data);
        setListSuggestion(res?.data?.data);
      }
    }
    getData();
  }, []);

  return (
    <div className="main">
      {listSuggestion?.map((i: any, index: number) => (
        <>
          <div
            className="title-3 text-[#667085] pb-[28px] flex gap-[4px] text-[14px] font-normal"
            key={Math.random()}
            onClick={() => setChosenLocation(i)}
          >
            <div>{i?.flag}</div>
            <div>{i?.name}</div>
            <div>{i?.countryCodes?.join(" ")}</div>
          </div>

          {index == 3 && allCountries?.length == listSuggestion?.length && (
            <div className="h-[1px] bg-[#F2F4F7] my-[20px] mt-[-8px]"></div>
          )}
        </>
      ))}
    </div>
  );
}

export default SearchHospital;
