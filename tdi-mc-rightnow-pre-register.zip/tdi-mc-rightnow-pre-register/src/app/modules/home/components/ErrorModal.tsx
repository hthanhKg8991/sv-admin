import Button from "@/core/components/Button";
import { Modal } from "antd";
import { useIntl } from "react-intl";

export default function ErrorModal({ message, onClose }: any) {
  const intl = useIntl();

  return (
    <Modal
      centered
      open={true}
      closable={false}
      className="classNameModal  z-100000"
      onCancel={onClose}
      style={{ maxWidth: 264 }}
      footer={
        <div className="text-center">
          <Button
            text={intl.formatMessage({ id: "CONFIRM" })}
            style={{
              backgroundColor: "#672EFE",
              color: "#ffffff",
              marginBottom: 12,
              borderRadius: "24px",
              padding: "8px 12px",
            }}
            className="!py-[8px] !px-[12px] !text-[14px] !font-medium !leading-[22px]"
            onClick={onClose}
          />
        </div>
      }
    >
      <p className="font-bold text-[16px] text-center text-[#000] leading-[20px]">
        {intl.formatMessage({ id: "ALERT" })}
      </p>
      <p className="text-center mt-[12px] mb-[24px]">{message}</p>
    </Modal>
  );
}
