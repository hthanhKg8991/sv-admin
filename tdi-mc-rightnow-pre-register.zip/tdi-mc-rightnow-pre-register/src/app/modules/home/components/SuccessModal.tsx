import Button from "@/core/components/Button";
import { Modal } from "antd";
import { useIntl } from "react-intl";

export default function SuccessModal({ title, message, onClose }: any) {
  const intl = useIntl();

  return (
    <Modal
      centered
      open={true}
      closable={false}
      className="classNameModal  z-100000"
      onCancel={onClose}
      style={{ maxWidth: 300 }}
      footer={
        <div className="text-center">
          <Button
            text={intl.formatMessage({ id: "CONFIRM" })}
            style={{
              backgroundColor: "#672EFE",
              color: "#ffffff",
              marginBottom: 12,
              padding: 10,
              borderRadius: "24px",
            }}
            onClick={onClose}
          />
        </div>
      }
    >
      <div className="success_modal">
        <p className="text-[16px] font-bold text-center mb-[12px]">{title}</p>
        <p className="text-center mb-[24px] text-[#000] text-[14px]">
          {message}
        </p>
      </div>
    </Modal>
  );
}
