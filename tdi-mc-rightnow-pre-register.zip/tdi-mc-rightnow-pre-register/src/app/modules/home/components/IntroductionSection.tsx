import { useIntl } from "react-intl";
import Text from "@/core/components/Text";
import picPerson from "/images/picPerson.png";
import number01 from "/images/number_01.png";
import number02 from "/images/number_02.png";
import number03 from "/images/number_03.png";
import number04 from "/images/number_04.png";
import number05 from "/images/number_05.png";
import rightNowCent from "/images/right-now-cent.png";
import { useLang } from "@/core/i18n";

export default function IntroductionSection() {
  const intl = useIntl();
  const lang = useLang();
  const renderIntroductionContent = (
    number: string,
    title: string,
    desc: string
  ) => {
    return (
      <div className="flex items-start gap-2 justify-center">
        <img src={number} alt="" />
        <div className="flex flex-col gap-1 items-start text-left w-[264px] md:w-[172px]">
          <Text
            variant={"xl"}
            className={`${
              lang === "ko"
                ? "text-[20px] leading-[26px]"
                : " text-lg  leading-[22px]"
            } font-bold whitespace-normal md:whitespace-pre-line`}
          >
            {title}
          </Text>
          <Text
            variant={"sm"}
            className="text-[14px] font-normal leading-[22px] text-black whitespace-pre-line"
          >
            {desc}
          </Text>
        </div>
      </div>
    );
  };

  return (
    <div className="md:w-[512px] px-[24px] md:px-[28px] relative">
      {/* <div className=" grid grid-cols-1 md:grid-cols-2">
        <div className="flex items-center md:items-start flex-col justify-center md:text-start">
          <Text variant={"md"} className="mt-3 text-[16px]">
            {intl.formatMessage({ id: "DATING_PLATFORM_DESCRIBE" })}
          </Text>
        </div>
        <div className="flex items-end justify-center mt-[14px]">
          <img src={picPerson} alt="pic person" className="w-[360px] h-[250px]" />
        </div>
      </div> */}

      <div className="py-[60px] flex flex-col md:grid md:grid-cols-2 gap-[24px] md:gap-y-[32px]">
        {renderIntroductionContent(
          number01,
          intl.formatMessage({ id: "EXCITING_DATING_EVERY_DAY" }),
          intl.formatMessage({ id: "EXCITING_DATING_EVERY_DESCRIBE" })
        )}
        {renderIntroductionContent(
          number02,
          intl.formatMessage({ id: "DOUBLE_THE_FUN" }),
          intl.formatMessage({ id: "DOUBLE_THE_FUN_DESCRIBE" })
        )}
        {renderIntroductionContent(
          number03,
          intl.formatMessage({ id: "LOOKING_FOR_MORE_FUN" }),
          intl.formatMessage({ id: "LOOKING_FOR_MORE_FUN_DESCRIBE" })
        )}
        {renderIntroductionContent(
          number04,
          intl.formatMessage({ id: "UNLIMITED_FUN_UNLIMITED_PROFIT" }),
          intl.formatMessage({
            id: "UNLIMITED_FUN_UNLIMITED_PROFIT_DESCRIBE",
          })
        )}
        {renderIntroductionContent(
          number05,
          intl.formatMessage({
            id: "SAFE_AND_RELIABLE_SPECIAL_DATING_SPACE",
          }),
          intl.formatMessage({
            id: "SAFE_AND_RELIABLE_SPECIAL_DATING_SPACE_DESCRIBE",
          })
        )}
        <div className="flex items-center justify-center">
          <img
            src={rightNowCent}
            alt="Right now cent"
            className="md:w-[298px] block md:hidden"
          />
        </div>
      </div>
      <div className=" absolute bottom-[60px] -right-6 hidden md:block">
        <img src={rightNowCent} alt="Right now cent" className="md:h-[144px]" />
      </div>
    </div>
  );
}
