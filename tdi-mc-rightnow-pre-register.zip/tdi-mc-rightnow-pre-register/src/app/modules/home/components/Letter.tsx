import { useLang } from "@/core/i18n";
import LetterKo from "/images/letterko.png";
import LetterEn from "/images/letteren.png";
import LetterVn from "/images/lettervn.png";

const Letter = () =>{
    const renderLetterImage = () =>{
        const lang = useLang();
    let letterImage = null;
    switch (lang) {
        case "vi":
            return letterImage = LetterVn
        case "en":
            return letterImage = LetterEn
        case "ko":
            return letterImage = LetterKo
        default:
            return;
    }
    }
    return <img src={renderLetterImage()} alt="Letter korea" className="w-[260px] h-[182px] md:w-[300px] md:h-[210px]" />
}
export default Letter;