import { useIntl } from "react-intl";
import lighting from "/icons/lighting.png";
import couponHeart from "/B_images/coupon_Heart.png";
import asterisk from "/B_icons/asterisk.svg";
import asteriskThink from "/B_icons/asterisk_think.svg";
import plus from "/B_icons/plus.svg";
import equal from "/B_icons/equal.svg";
import representationOfResellingAndMarket from "/B_images/representation-of-reselling-and-market.png";
import { useLang } from "@/core/i18n";

const Benefit = () => {
  const intl = useIntl();
  const lang = useLang();
  const isByLang = () => {
    let fontSize = "";
    let lineHeight = "";
    let letterSpacing = "";
    switch (lang) {
      case "en":
        fontSize = "16px";
        lineHeight = "18px";
        break;
      case "vi":
        fontSize = "13px";
        lineHeight = "24px";
        letterSpacing = "0.26px";
        break;
      case "ko":
        fontSize = "16px";
        lineHeight = "24px";
        break;
      default:
        break;
    }
    return { fontSize, lineHeight, letterSpacing };
  };
  const renderRectangle = () => {
    let paddingLeft = "";
    let paddingRight = "";
    switch (lang) {
      case "en":
        paddingLeft = "pl-[26px]";
        paddingRight = "pr-[16px]";
        break;
      case "vi":
        paddingLeft = "pl-[12px]";
        paddingRight = "pr-[10px]";
        break;
      case "ko":
        paddingLeft = "pl-[32px]";
        paddingRight = "pr-[39px]";
        break;
      default:
        break;
    }
      
    return (
      <div className={`${paddingLeft} ${paddingRight} bg-white/60 rounded-lg flex flex-row items-center m-auto h-[68px] w-[288px] mt-[17px] justify-around relative border border-solid border-indigo-50 flex-shrink`}>
        <div className="flex flex-col items-center ">
          <h2 className={`text-[#0094FF] text-[20px] font-bold not-italic leading-5 font-gmarket mb-1`}>
            50%
          </h2>
          <span className={`font-${lang !=='en' ?"bold": "extrabold"} text-[10px] text-[#0094FF] not-italic leading-[10px] -tracking-[0.2px]`}>
            {intl.formatMessage({ id: "B_BASIC_RATE" })}
          </span>
        </div>
        <span className={`${lang ==='vi'?"absolute left-[88px] top-[24px]":"static"}`}>
          <img src={plus} alt="plus" width={"12px"} />
        </span>
        <div className="flex flex-col text-center">
          <h2 className="text-[#0094FF] text-[20px] font-bold not-italic leading-5 font-gmarket  mb-1">
            10%
          </h2>
          <span className={`font-${lang !=='en' ?"bold": "extrabold"} text-[10px] text-[#0094FF] not-italic leading-[10px] -tracking-[0.2px]`}>
            {intl.formatMessage({ id: "B_ADDITIONAL_RATE" })}
          </span>
        </div>
        <span className={`${lang ==='vi'?"absolute left-[156px] top-[24px]":"static"}`}>
        <img src={equal} alt="plus" width={"12px"} />
        </span>
        <div className={`flex flex-col ${lang ==='ko'? 'text-left': 'text-center'}`}>
          <h2 className="text-[#FF46C0] text-[26px] font-bold not-italic font-gmarket  mb-1">
            60%
          </h2>
          <span className={`font-${lang !=='en' ?"bold": "extrabold"} text-[10px] text-[#FF46C0] not-italic -tracking-[0.2px]`}>
            {intl.formatMessage({ id: "B_VIP_COMMISSION_RATE" })}
          </span>
        </div>
      </div>
    );
  };
  const renderIconAbsolute = () => {
    return (
      <div className="absolute w-full top-0">
        <div className="absolute top-[193px] -right-[31px]">
          <img src={asterisk} alt="asterisk" />
        </div>
        <div className="absolute top-[369px] -left-[29px]">
          <img src={asteriskThink} alt="asterisk"/>
        </div>
      </div>
    );
  };
  const renderBenefit1 = () => {
    return (
      <>
        <div className="flex flex-row items-center justify-center pt-[36px] text-[#FFAEEE] text-xl font-bold not-italic gap-[6px]">
          <img src={lighting} alt="" width="8px" height="20px" />
          <h1 className="text-[20px] font-bold leading-5 not-italic">
            {intl.formatMessage({ id: "B_BENEFIT_1" })}
          </h1>
          <img src={lighting} alt="" width="8px" height="20px" />
        </div>
        <div className="w-full flex flex-col items-center justify-center mt-[8px]">
          <div
            className={`w-[328px] h-[50px] flex items-center justify-center`}
          >
            <h5
              className={`text-[${isByLang().fontSize}] -tracking-[${
                isByLang().letterSpacing
              }] 
            leading-[${isByLang().lineHeight}] 
            not-italic font-semibold text-white text-center justify-center whitespace-pre-line `}
            >
              {intl.formatMessage({ id: "B_BENEFIT_1_DESCRIPTION" })}
            </h5>
          </div>
          <div className="flex justify-center mt-[20px]">
            <img src={couponHeart} alt="" width={"212px"} height={"162px"}/>
          </div>
        </div>
        {renderRectangle()}
      </>
    );
  };
  const renderBenefit2 = () => {
    return (
      <>
        <div className="flex flex-row items-center justify-center pt-[32px] text-[#FFAEEE] text-xl font-bold not-italic gap-[6px]">
          <img src={lighting} alt="" width="8px" height="20px" />
          <h1 className="text-[20px] font-bold leading-5">
            {intl.formatMessage({ id: "B_BENEFIT_2" })}
          </h1>
          <img src={lighting} alt="" width="8px" height="20px" />
        </div>
        <div className="w-full flex flex-col items-center justify-center">
          <div
            className={`w-[328px] mt-[8px] flex items-center justify-center`}
          >
            <h5
              className={`text-[${
                isByLang().fontSize
              }] leading-[${isByLang().lineHeight}] -tracking-[0.26px] align-middle not-italic font-semibold text-white text-center justify-center whitespace-pre-line `}
            >
              {intl.formatMessage({ id: "B_BENEFIT_2_DESCRIPTION_FIRST" })}
              <span className="text-[20px] font-extrabold text-[#51EAFF] -tracking-[0.4px] not-italic leading-[24px]">
                &nbsp;5
              </span>
              <span className="text-[13px] font-extrabold text-[#51EAFF] -tracking-[0.26px] leading-[24px]">
                %&nbsp;
              </span>
              {intl.formatMessage({ id: "B_BENEFIT_2_DESCRIPTION_LAST" })}
            </h5>
          </div>
          <div className="flex flex-col items-center text-center justify-center mt-[21px]">
            <img
              src={representationOfResellingAndMarket}
              alt="representation of reselling and market"
              width={"158px"}
            />
            <div className="w-[284px] mb-[26px] mt-[17px]">
              <p className={`leading-[${lang ==='ko'? '18px':'12px'}] text-[10px] text-white opacity-70 not-italic font-normal whitespace-pre-line`}>
                {intl.formatMessage({ id: "B_BENEFIT_AVAILABLE" })}
              </p>
            </div>
          </div>
        </div>
      </>
    );
  };
  return (
    <div className="bg-[url('/B_images/bg-benefit.png')] bg-cover h-full w-full relative overflow-x-hidden">
      <div className=" max-w-sm relative m-auto">
        {renderBenefit1()}
        {renderBenefit2()}
        {renderIconAbsolute()}
      </div>
    </div>
  );
};

export default Benefit;
