import { useLang } from "@/core/i18n";
import { useIntl } from "react-intl";
import lighting from "/icons/lighting.png";
import BCupid from "/B_images/B_Cupid.png";
import BLetterStar from "/B_images/B_letter_star.png";
import React from "react";
import { stringInterpolateStyle } from "@/core/utils/utils";

const About = () => {
  const intl = useIntl();
  const lang = useLang();
  const isByLang = () => {
    let lineHeight = "";
    let lineHeightMessageIncome = "";
    switch (lang) {
      case "vi":
        lineHeight = "leading-[22px]";
        lineHeightMessageIncome = "leading-[25px]";
        break;
      case "en":
        lineHeight = "leading-[24px]";
        lineHeightMessageIncome = "leading-[24px]";
        break;
      case "ko":
        lineHeight = "leading-[25px]";
        lineHeightMessageIncome = "leading-[25px]";
        break;
      default:
        break;
    }
    return { lineHeight, lineHeightMessageIncome };
  };
  return (
    <div className="bg-black">
      <div className=" max-w-sm relative m-auto">
        <div className="flex flex-row items-center justify-center pt-[36px] text-[#FF72E1] text-xl font-bold not-italic gap-[6px]">
          <img src={lighting} alt="" width="8px" height="20px" />
          <h1 className="text-[20px] font-bold leading-5 not-italic">
            {intl.formatMessage({ id: "B_ABOUT_RIGHT_NOW" })}
          </h1>
          <img src={lighting} alt="" width="8px" height="20px" />
        </div>
        <div className=" w-full flex items-center justify-center mt-[56px]">
          <img src={BCupid} alt="cupid" className="w-[328px] h-[160px]" />
        </div>
        <div className="text-center mt-[24px]">
          <p
            className="text-white whitespace-pre-line text-[18px] not-italic font-bold leading-[24px]"
            dangerouslySetInnerHTML={{
              __html: stringInterpolateStyle(
                intl.formatMessage({ id: "B_THE_MORE_MESSAGE_INCOME" }),
                [
                  intl.formatMessage({ id: "B_MESSAGE" }),
                  intl.formatMessage({ id: "B_INCOME" }),
                ],
                `text-[#FF72E1] text-[18px] font-bold ${isByLang().lineHeightMessageIncome}`
              ),
            }}
          />
        </div>
        <div className=" w-full flex items-center justify-center mt-[36px] m-auto">
          <img
            src={BLetterStar}
            alt="letter star"
            className="w-[180px] h-[160px]"
          />
        </div>
        <div className="text-center mt-[24px] w-[328px] m-auto">
          <p
            className={`${isByLang().lineHeight} text-white whitespace-pre-line text-[18px] not-italic font-bold`}
            dangerouslySetInnerHTML={{
              __html: stringInterpolateStyle(
                intl.formatMessage({ id: "B_SELL_PHOTOS_TO_OTHERS" }),
                [
                  intl.formatMessage({ id: "B_SELL" }),
                  intl.formatMessage({ id: "B_PHOTOS" }),
                  intl.formatMessage({ id: "B_INCOME" }),
                ],
                "text-[#FF72E1]"
              ),
            }}
          />
        </div>
        <div className="mt-[16px] pb-[86px] text-center">
          <span className="text-[8px] leading-[8px] text-white/30 not-italic font-medium">{intl.formatMessage({ id: "B_SOURCE_PHOTOS"})}</span>
        </div>
      </div>
    </div>
  );
};
export default About;
