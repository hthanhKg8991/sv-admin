import Text from "@/core/components/Text";
import ArrowUp from "/icons/arrow-up.svg";
import Layout from "@/core/layout";
import { useIntl } from "react-intl";
import { useEffect, useState } from "react";
import IntroductionSection from "./components/IntroductionSection";
import ReleaseSection from "./components/ReleaseSection";
import CouponSection from "./components/CouponSection";
import RegisterForm from "./components/RegisterForm";
import LoginForm from "./components/LoginForm";
import InvitedFriends from "../InvitedFriends";
import Letter from "./components/Letter";
import picPerson from "/images/picPerson.png";
import { useLang } from "@/core/i18n";
import BGblue from "/images/BG_blue.png";
import BGBubble from "/images/bg_bubble.png";
import { linkClickSave } from "@/app/services/myInfo";
import Header from "@/core/layout/Header";
import Benefit from "./components/VersionB/Benefit";
import B_Heart from "/B_images/B_heart.png";
import CoinLayerFold from "/B_images/B_fold_coin.svg";
import CoinLayerMobile from "/B_images/B_mobile_coin.svg";

import B_ArrowDown from "/B_icons/B_arrowdown.svg";
import About from "./components/VersionB/About";

const HomePage = () => {
  const intl = useIntl();
  const lang = useLang();

  const [isShowRegisterForm, setIsShowRegisterForm] = useState(false);
  const [isShowModal, setIsShowModal] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isShowLoginForm, setIsShowLoginForm] = useState(false);
  const [isShowInvitedFriend, setIsShowInvitedFriend] = useState(false);

  const token = localStorage.getItem("token");

  const query = new URLSearchParams(location.search);

  const agencyCode = query.get("agencyCode");
  const referralCode = query.get("referralCode");

  useEffect(() => {
    if (agencyCode || referralCode) linkClickSave(agencyCode, referralCode);
  }, [agencyCode, referralCode]);

  if (isShowInvitedFriend)
    return (
      <InvitedFriends
        goBack={() => {
          setIsShowInvitedFriend(false);
          // localStorage.removeItem("token");
        }}
      />
    );

  let b_dating_app;
  let hundred_milion;
  let register_now;

  switch (lang) {
    case "ko":
      b_dating_app = (
        <div
          className={`text-[15px] text-[#FFE1F8] pt-[62px] text-center font-light mb-[14px]`}
        >
          대화만해도 수익이 생기는{" "}
          <span className="font-medium">고수익 데이팅 앱</span>
        </div>
      );

      hundred_milion = (
        <div className="whitespace-pre-line font-bold text-center font-['Jalnan'] flex items-center flex-col milion_shadow  mb-[24px]">
          <div className="mb-[8px] text-[40px] milion w-[256px]">
            역대급 월수익
          </div>
          <div className="text-[22px] milion w-[256px]">
            {" "}
            100,000,000 VND 이상{" "}
          </div>
        </div>
      );

      register_now = (
        <div className="text-[white] text-[16px] text-[16px] font-semibold leading-[26px]  py-[22px] px-[48px]">
          <div>
            지금 라잇나우에 <span className="text-[#FFA8EE]">사전예</span>
            약하고,
          </div>
          <div>
            <span className="text-[#FFA8EE]">혜택</span>을 받아보세요.
          </div>
          <div>2024년 1월 15일 출시!</div>
        </div>
      );
      break;

    case "vi":
      b_dating_app = (
        <div
          className={`text-[13.5px] text-[#FFE1F8] pt-[62px] text-center font-light mb-[14px]`}
        >
          App hẹn hò đem thu nhập khủng chỉ qua trò chuyện
        </div>
      );

      hundred_milion = (
        <div className="text-[26px] font-bold text-center flex items-center flex-col milion_shadow  mb-[38px]">
          <div className="mb-[8px] milion leading-[30px]">
            Thu nhập tháng siêu khủng
          </div>
          <div className="milion"> Trên 100,000,000 vnd </div>
        </div>
      );

      register_now = (
        <div className="text-[white]  py-[20px] px-[16px]">
          <div className="text-[18px] leading-[22px]">
            <span className="text-[#FFA8EE] font-bold ">Đăng kí</span> tham gia
            trước tại
          </div>
          <div className="text-[18px]  leading-[22px] mb-[6px]">
            Right Now để nhận{" "}
            <span className="text-[#FFA8EE] font-bold ">ưu đãi</span>
          </div>
          <div className="text-[16px] font-extrabold leading-[30px]">
            Ra mắt ngày 15 tháng 1 năm 2024
          </div>
        </div>
      );
      break;

    case "en":
      b_dating_app = (
        <div
          className={`text-[13.5px] text-[#FFE1F8] pt-[62px] text-center mb-[16px]`}
        >
          Dating apps bring huge income just through chatting
        </div>
      );

      hundred_milion = (
        <div className="font-['Jalnan']  font-bold text-center flex items-center flex-col milion_shadow  mb-[-24px]">
          <div className=" milion text-[35px] leading-[44px]"></div>
          <div className=" whitespace-pre-line  mb-[8px] milion text-[35px] leading-[44px]">
            Super huge {"\n"}monthly income
          </div>
          <div className="milion text-[21px] leading-[24px]">
            {" "}
            More than 100,000,000 vnd{" "}
          </div>
        </div>
      );

      register_now = (
        <div className="text-[white] py-[22px] px-[48px] leading-[26px]">
          <div className="text-[17px] ">
            <span className="text-[#FFA8EE] font-bold ">Pre-order</span> now at
            Right Now
          </div>
          <div className="text-[17px]">
            and receive{" "}
            <span className="text-[#FFA8EE] font-bold ">benefits.</span>
          </div>
          <div className="text-[16px] font-bold ">
            Launching January 15, 2024!
          </div>
        </div>
      );
      break;
  }

  return (
    <div className="planB">
      <Header openLoginForm={() => setIsShowLoginForm(true)} />
      <div className="flex justify-center items-center relative">
        <img
          src={CoinLayerFold}
          className="absolute top-[26px] overflow-hidden h-[620px] object-none"
        />
      </div>
      <div className="background-linear">
        {b_dating_app}
        <div className="milion_shadow">{hundred_milion}</div>

        <div className="flex justify-center">
          <img src={B_Heart} width={360} />
        </div>

        <div className="flex justify-center">
          <div className="box_bg text-center rounded-[8px] border border-solid border-[#FFC2F2] backdrop-blur-[2px]">
            {register_now}
          </div>
        </div>

        <div className="mt-[24px] flex justify-center pb-[29px]">
          <img src={B_ArrowDown} />
        </div>
      </div>
      <Benefit />
      <About />

      {isShowRegisterForm ? (
        <div className="md:w-[400px]">
          <RegisterForm onClose={() => setIsShowRegisterForm(false)} />
        </div>
      ) : (
        <button
          onClick={() => setIsShowRegisterForm(true)}
          className="py-[18px] px-[32px] center flex fixed bottom-0 bg-THIRD_COLOR rounded-tl-2xl rounded-tr-2xl text-center items-center justify-center w-full md:w-[400px] lg:justify-center lg:items-center py-[18px] md:text-[20px]"
        >
          <Text className=" text-sm font-bold text-[18px]">
            {intl.formatMessage({ id: "REGISTER" })}
          </Text>
          <img src={ArrowUp} alt="arrow up" />
        </button>
      )}

      {isShowLoginForm && (
        <LoginForm
          onClose={() => setIsShowLoginForm(false)}
          setIsShowInvitedFriend={setIsShowInvitedFriend}
        />
      )}
    </div>
  );
};
export default HomePage;
