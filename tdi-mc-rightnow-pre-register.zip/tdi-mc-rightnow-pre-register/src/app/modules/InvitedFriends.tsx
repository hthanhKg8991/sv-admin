import Button from "@/core/components/Button";
import CopyToClipboard from "react-copy-to-clipboard";
import CopyIcon from "/icons/copy.svg";
import ShareIcon from "/icons/share.svg";
import ArrowLeftIcon from "/icons/arrowLeft.svg";
import LogoutIcon from "/icons/logout.svg";
import axios from "axios";
import { useEffect, useState } from "react";
import { getMyInfo, getReferalUsers } from "../services/myInfo";
import { useIntl } from "react-intl";
import { useLang } from "@/core/i18n";
import SuccessModal from "./home/components/SuccessModal";
import TelegramIcon from "/icons/zalo.png";
import { commafy } from "@/core/utils/utils";
import { Modal, Tooltip } from "antd";
import { useNavigate } from "react-router-dom";
import BlackExclamtion from "/icons/black_exclamation.svg";
import BlueExclamtion from "/icons/blue_exclamation.svg";

export default function InvitedFriends({ goBack }: any) {
  const intl = useIntl();
  const lang = useLang();
  const navigate = useNavigate();
  const [openTooltip, setOpenTooltip] = useState(false);

  const [isShowCopySuccess, setIsShowCopySuccess] = useState(false);
  const [isShowLogoutModal, setIsShowLogoutModal] = useState(false);

  const token = localStorage.getItem("token");
  axios.defaults.headers.common = { Authorization: `Bearer ${token}` };

  const [listUsers, setListUsers] = useState([]);
  const [totalUsers, setTotalUsers] = useState<any>(0);
  const [name, setName] = useState();
  const [link, setLink] = useState();

  useEffect(() => {
    async function getData() {
      const res = await getReferalUsers(token);
      if (res.status == 200) {
        setListUsers(res?.data?.data);
        setTotalUsers(res?.data?.total);
      }

      const myinfoRes = await getMyInfo(token);
      if (myinfoRes.status == 200) {
        setLink(myinfoRes?.data?.shortLink);
        setName(myinfoRes?.data?.name);
      } else {
        localStorage.removeItem("token");
        navigate("/");
      }
    }

    getData();
  }, [token]);

  const renderFriendListText = () => {
    let imgCoupon = null;
    switch (lang) {
      case "en":
        imgCoupon = `List of pre-registered friends invited by ${name || "-"}`;
        break;
      case "vi":
        imgCoupon = `Danh sách bạn bè đã đăng kí trước của bạn ${
          name || "-"
        } đã mời`;
        break;

      case "ko":
        imgCoupon = `${
          name || "-"
        } 님이 추천하신 분들의\n 사전 예약자 명단입니다.`;
        break;
      default:
        break;
    }
    return imgCoupon;
  };

  const renderFriendCountText = () => {
    let imgCoupon = null;
    switch (lang) {
      case "en":
        imgCoupon = `${totalUsers} friends`;
        break;
      case "vi":
        imgCoupon = `Tổng ${totalUsers} người`;
        break;

      case "ko":
        imgCoupon = `총 ${totalUsers}명`;
        break;
      default:
        break;
    }
    return imgCoupon;
  };

  const renderIconWithTooltip = () => {
    let imgCoupon = null;
    switch (lang) {
      case "en":
        imgCoupon = (
          <Tooltip
            placement="topRight"
            title={intl.formatMessage({ id: "EARNING-EXPLAIN" })}
            color="#475467"
            align={{ offset: [13, -10] }}
            overlayClassName="english-tooltip"
            trigger="click"
          >
            <img src={BlackExclamtion} />
          </Tooltip>
        );
        break;
      case "vi":
        imgCoupon = (
          <Tooltip
            placement="topRight"
            title={intl.formatMessage({ id: "EARNING-EXPLAIN" })}
            color="#475467"
            align={{ offset: [13, -10] }}
            overlayClassName="vietnam-tooltip"
            trigger="click"
          >
            <img src={BlackExclamtion} />
          </Tooltip>
        );
        break;

      case "ko":
        imgCoupon = (
          <Tooltip
            placement="top"
            title={intl.formatMessage({ id: "EARNING-EXPLAIN" })}
            color="#475467"
            overlayClassName="korean-tooltip"
            trigger="click"
          >
            <img src={BlackExclamtion} />
          </Tooltip>
        );
        break;
      default:
        break;
    }
    return imgCoupon;
  };

  const totalMoney = 30000000 * Number(totalUsers);
  const netMoney = (totalMoney * 5) / 100;

  const renderProfit = () => {
    return (
      <div
        className="bg-[#F2F4F7] rounded-2xl"
        onClick={() => setOpenTooltip(false)}
      >
        <div className="bg-[#4652BE] rounded-tl-2xl rounded-tr-2xl text-center">
          <p className="text-xs font-normal not-italic text-white py-[5px]">
            {intl.formatMessage({ id: "INVITE_FRIEND" })}
          </p>
        </div>
        <div className="flex flex-col justify-around p-4 gap-[8px]">
          <div
            className={`flex gap-[4px] flex-wrap ${
              lang != "ko" ? "flex-col text-center" : "flex-row justify-around"
            }`}
          >
            <p className="text-[12px] leading-[18px] font-normal not-italic text-[#667085]">
              {intl.formatMessage({ id: "TOTAL_EARNINGS" })}
            </p>
            <p className="text-[12px] leading-[18px] font-normal not-italic text-[#667085]">
              {commafy(totalMoney)} {intl.formatMessage({ id: "CURRENCY" })}
            </p>
          </div>
          <div
            className={`flex gap-[4px] flex-wrap ${
              lang != "ko" ? "flex-col text-center" : "flex-row justify-around"
            }`}
          >
            <div className="flex justify-center gap-[4px] items-center">
              <p className="text-base font-bold not-italic text-[#000000] text-[20px]">
                = {intl.formatMessage({ id: "EARNINGS" })}
              </p>

              {renderIconWithTooltip()}
            </div>

            <p className="text-[20px] font-bold not-italic text-[#F47DAA]">
              {commafy(netMoney)} {intl.formatMessage({ id: "CURRENCY" })}
            </p>
          </div>
        </div>
      </div>
    );
  };
  return (
    <div>
      <div className="flex justify-between">
        <img
          src={ArrowLeftIcon}
          className="ml-[20px] mt-[16px] md:ml-[28px] w-[24px] h-[24px]"
          onClick={() => navigate("/")}
        />
        <img
          src={LogoutIcon}
          className="mr-[20px] mt-[16px] md:mr-[28px] w-[24px] h-[24px]"
          onClick={() => {
            setIsShowLogoutModal(true);
          }}
        />
      </div>
      <div
        className={`justify-center flex overflow-auto response-modal w-full mb-[56px] px-[20px] md:px-[68px]`}
      >
        <div className="w-[320px]">
          <div className="text-center mb-[16px] flex items-center flex-col">
            <div
              className={`${
                lang == "ko" ? "w-full" : " w-full"
              } text-[#4652BE] text-center font-bold leading-[22px] text-[18px] mb-[16px] mt-[8px] whitespace-pre-line`}
            >
              {renderFriendListText()}
            </div>

            <div
              className={`flex  ${
                lang != "ko" ? "flex-col text-center" : "flex-row gap-[8px]"
              }`}
            >
              <div className="text-[#4652BE] text-center font-medium text-[16px] leading-[24px]">
                {intl.formatMessage({ id: "TOTAL-REF" })}
              </div>
              <div className="text-[16px] font-bold text-[#F47DAA] leading-[24px]">
                {renderFriendCountText()}
              </div>
            </div>
          </div>
          {renderProfit()}

          <div className="h-[1px] bg-[#F2F4F7] my-[28px]" />

          <div className="text-[#4652BE] font-medium text-[14px] leading-[22px] mb-[8px]">
            {intl.formatMessage({ id: "MY-LINK" })}
          </div>

          <div className="text-[#672EFE] text-[14px] leading-[18px] rounded-[8px] bg-[#EAECF0] px-[16px] py-[11px]  mb-[16px]">
            {link}
          </div>

          <div className="text-center gap-[8px]">
            <div className="flex mb-[16px] gap-[8px]">
              <CopyToClipboard
                text={link || "https://reservation.rightnow.vn"}
                onCopy={() => setIsShowCopySuccess(true)}
              >
                <Button className="!text-[#fff] !text-[16px] !font-medium !bg-[#672EFE] !rounded-[24px] !px-[16px] !py-[12px] !h-[48px] !gap-[4px]">
                  {intl.formatMessage({ id: "COPY-LINK" })}{" "}
                  <img src={CopyIcon} className="w-[24px]" />
                </Button>
              </CopyToClipboard>

              <Button
                className="!text-[#ffff] !text-[16px] !font-medium !bg-[#F47DAA] !rounded-[24px]  !px-[16px] !py-[12px] !h-[48px] !gap-[4px]"
                onClick={() => {
                  const shareData = {
                    // title: "RIGHTNOW/HẸN HÒ BẠN MỚI MANG ĐẾN THU NHẬP KHỦNG",
                    // text: "Nhận thu nhập cao hơn người khác chỉ bằng cách đăng kí thành viên trước khi ra mắt app chính thức!! Hãy tham gia Right Now ngay nhé",
                    url: link,
                  };

                  if (navigator?.share && navigator?.canShare(shareData)) {
                    navigator.share(shareData);
                  } else {
                    //setErrorMessagePassword("Device do not support this function");
                  }
                }}
              >
                {intl.formatMessage({ id: "SHARE" })}{" "}
                <img src={ShareIcon} className="h-[24px]" />
              </Button>
            </div>

            <a href="https://zalo.me/g/markqz677" target="_blank">
              <Button className="!text-[#ffff] !text-[16px] !font-medium !bg-[#2B66F6] !rounded-[24px]  !py-[12px] !px-[16px] !gap-[4px]">
                {intl.formatMessage({ id: "JOIN_ZALO_RIGHT_NOW" })}{" "}
                <img src={TelegramIcon} className="h-[24px]" />
              </Button>
            </a>
            <div className="flex mt-[8px]">
              <img src={BlueExclamtion} className="w-[18px] h-[18px]" />
              <div className="text-[#2B66F6] text-[12px] leading-[18px] text-start">
                {intl.formatMessage({
                  id: "ZALO-BENEFIT",
                })}
              </div>
            </div>
          </div>

          <div className="h-[1px] bg-[#F2F4F7] mt-[28px]" />

          {listUsers?.length == 0 ? (
            <div className="flex items-center justify-center text-[14px] text-[#667085] h-[120px]">
              {intl.formatMessage({ id: "NO-ONE" })}
            </div>
          ) : (
            <div className="mt-[28px] mb-[60px] relative overflow-x-auto shadow-md sm:rounded-lg">
              <table className="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
                <thead className="text-xs bg-[#667085] text-[14px] font-medium text-[#fff]">
                  <tr>
                    <th
                      scope="col"
                      className="px-6 py-3 font-medium border-[#fff] border-solid border-e text-[14px] text-center"
                    >
                      {intl.formatMessage({ id: "NAME" })}
                    </th>
                    <th
                      scope="col"
                      className="px-6 py-3 font-medium text-[14px]  text-center"
                    >
                      {intl.formatMessage({ id: "PHONE_NUMBER" })}
                    </th>
                  </tr>
                </thead>
                <tbody className="text-[#4652BE] text-[14px]">
                  {listUsers?.map((i: any, index) => {
                    if (index % 2 == 0)
                      return (
                        <tr className="bg-[#F9FAFB]">
                          <td className="text-center h-full p-[7px] border-[#fff] border-solid border-e text-center">
                            {i?.customerName || "-"}
                          </td>
                          <td className="text-center h-full p-[7px] text-center">
                            {i?.customerPhone || "-"}
                          </td>
                        </tr>
                      );
                    else
                      return (
                        <tr className="bg-[#EAECF0]">
                          <td className="text-center p-[7px] border-[#fff] border-solid border-e text-center">
                            {i?.customerName || "-"}
                          </td>
                          <td className="text-center p-[7px] text-center">
                            {i?.customerPhone || "-"}
                          </td>
                        </tr>
                      );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
      <Button
        text={intl.formatMessage({ id: "CONFIRM" })}
        className="bottom-0 text-lg font-bold bg-[#672EFE]"
        style={{ position: "fixed" }}
        onClick={() => navigate("/")}
      />
      {isShowCopySuccess && (
        <SuccessModal
          title={intl.formatMessage({ id: "ALERT" })}
          message={intl.formatMessage({ id: "COPY-SUCCESS" })}
          onClose={() => setIsShowCopySuccess(false)}
        />
      )}

      {isShowLogoutModal && (
        <LogoutModal
          onClose={() => {
            setIsShowLogoutModal(false);
          }}
        />
      )}
    </div>
  );
}

function LogoutModal({ onClose }: any) {
  const intl = useIntl();
  const navigate = useNavigate();

  return (
    <div className="notify-modal">
      <Modal
        centered
        open={true}
        closable={false}
        className="classNameModal  z-100000"
        onCancel={onClose}
        style={{ maxWidth: 300 }}
        footer={
          <div className="text-center flex gap-[8px]">
            <Button
              text={intl.formatMessage({ id: "CANCLE" })}
              style={{
                backgroundColor: "#F2F4F7",
                color: "#667085",
                padding: 10,
                borderRadius: "24px",
              }}
              onClick={onClose}
            />
            <Button
              text={intl.formatMessage({ id: "LOGOUT" })}
              style={{
                backgroundColor: "#672EFE",
                color: "#ffffff",
                padding: 10,
                borderRadius: "24px",
              }}
              onClick={() => {
                localStorage.removeItem("token");
                navigate("/");
              }}
            />
          </div>
        }
      >
        <div className="success_modal">
          <p className="font-bold text-[16px] text-center text-[#000] leading-[20px]">
            {intl.formatMessage({ id: "ALERT" })}
          </p>
          <p className="text-center mt-[12px] mb-[24px] text-[#000] text-[14px]">
            {intl.formatMessage({ id: "LOGCONFIRM" })}
          </p>
        </div>
      </Modal>
    </div>
  );
}
